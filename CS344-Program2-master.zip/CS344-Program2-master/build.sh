gcc -g -Wall newtoner.buildrooms.c -o newtoner.buildrooms
./newtoner.buildrooms
gcc -g -Wall -o newtoner.adventure newtoner.adventure.c -lpthread
./newtoner.adventure
