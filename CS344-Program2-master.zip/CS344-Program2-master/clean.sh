rm -rf newtoner.rooms.*
