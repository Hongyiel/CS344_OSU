$ ./build.sh
