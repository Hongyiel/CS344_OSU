* Student Name:  Hongyiel Suh
* Student Number: 933612189
* Class: CS344
* Assignment 4
* OTP
* This file for help document that activating program


*-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-*  
Typing "compileall" command on the command line it will compile all program to run at once


According to p4gradingscope most of program was successful running.
*-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-**-*-*  
