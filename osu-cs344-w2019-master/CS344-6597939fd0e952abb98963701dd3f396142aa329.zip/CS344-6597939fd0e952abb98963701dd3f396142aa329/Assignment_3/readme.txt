Compiling information for the small shell program
executable name: smallsh

Enter the following line into the terminal 
to compile the small shell program: 

gcc -o smallsh smallsh.c
