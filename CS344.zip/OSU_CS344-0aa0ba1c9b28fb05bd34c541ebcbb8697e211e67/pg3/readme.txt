To compile this code, simply use a terminal to navigate to the same directory as smallsh.c and the makefile. Then, run the command "make".
Feel free to edit the compile command in the makefile to turn on any flags or compile options you would like.
